library(testthat)
library(ars)
library(pracma)

test_check("ars")
